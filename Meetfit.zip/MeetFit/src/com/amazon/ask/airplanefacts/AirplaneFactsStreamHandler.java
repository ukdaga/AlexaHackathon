package com.amazon.ask.airplanefacts;

import com.amazon.ask.Skill;
import com.amazon.ask.Skills;
import com.amazon.ask.SkillStreamHandler;
import com.amazon.ask.airplanefacts.handlers.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class AirplaneFactsStreamHandler extends SkillStreamHandler {

    static final Logger log = LogManager.getLogger(AirplaneFactsStreamHandler.class);

    private static Skill getSkill() {
        System.out.println("Devansh here!");
        log.info("Logger - Devansh - AirplaneFactsStreamHandler called!");
        return Skills.standard()
                .addRequestHandlers(
                        new CancelandStopIntentHandler(),
                        new AddIntentHandler(),
                        new NotifyChangeIntentHandler(),
                        new StartMeetingIntentHandler(),
                        new EndMeetingIntentHandler(),
                        new NotifyChangeIntentHandler(),
                        new RecapLastMeetingIntentIntentHandler(),
                        new CreateTeamIntentHandler(),
                        new FactIntentHandler(),
                        new HelpIntentHandler(),
                        new LaunchRequestHandler(),
                        new SessionEndedRequestHandler(),
                        new FallBackIntentHandler())
                // Add your skill id below and uncomment to enable skill ID verification
                // .withSkillId("")
                .build();
    }

    public AirplaneFactsStreamHandler() {
        super(getSkill());
    }

}
