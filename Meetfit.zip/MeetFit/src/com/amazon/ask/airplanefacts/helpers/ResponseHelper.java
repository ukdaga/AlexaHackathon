package com.amazon.ask.airplanefacts.helpers;

import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.model.Response;

import java.util.Optional;

public class ResponseHelper {

    public static final String TITLE = "MeetFit";

    public static Optional<Response> getResponseAbruptly(HandlerInput handlerInput, String primaryText2) {
        String primaryText;
        primaryText = primaryText2;
        String speechText = "<speak>" + primaryText + "</speak>";
        return handlerInput.getResponseBuilder()
                .withSpeech(speechText)
                .withSimpleCard(TITLE, primaryText)
                .withReprompt(speechText)
                .build();
    }

}
