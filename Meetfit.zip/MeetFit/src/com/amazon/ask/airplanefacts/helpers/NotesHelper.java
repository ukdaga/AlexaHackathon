package com.amazon.ask.airplanefacts.helpers;

import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.Notes;
import com.amazon.ask.airplanefacts.util.HibernateUtil;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class NotesHelper extends ParentDbHelper {

    public static String COLOUMN_MEETING_ID = "meetingId";
    public static String COLOUMN_MEETING_TYPE = "MeetingType";
    public static String COLOUMN_MEETING_STATUS = "MeetingStatus";

    public DBResponseModel getTeamProfileData(String coloumn, String str) {
        ArrayList<Notes> notes = new ArrayList<>();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            SQLQuery query = session.createSQLQuery("select id, meetingId , content, timestamp,personName,deadLine,noteType from Notes where " + coloumn + "=\'" + str+ "\'");
            List<Object[]> rows = query.list();

            for (Object[] row : rows) {
                Notes emp = new Notes();
                emp.setId(Integer.parseInt(row[0].toString()));
                emp.setMeetingId(Integer.valueOf(row[1].toString()));
                emp.setContent(row[2].toString());
                emp.setTimestamp(Timestamp.valueOf(row[3].toString()));
                if(row[4] != null && row[4].toString() != null)
                    emp.setPersonName(row[4].toString());
                else
                    emp.setPersonName("all");
                if(row[5] != null && row[5].toString() != null)
                    emp.setDeadLine(Timestamp.valueOf(row[5].toString()));
                emp.setNoteType(row[6].toString());
                notes.add(emp);
            }
            for (Notes employee : notes) {
                log.info("Notes : " + employee);
            }
        }

        if (notes.size() == 0)
            return getDbResponseModel(null);
        return getDbResponseModel(notes);
    }

    public DBResponseModel getNotesForID(String coloumn, Integer id) {
        return getTeamProfileData(coloumn, id.toString());
    }

    private DBResponseModel getDbResponseModel(Object pojo) {
        DBResponseModel dbResponseModel = new DBResponseModel();
        if (pojo != null) {
            dbResponseModel.setFound(true);
            dbResponseModel.setPojo(pojo);
        } else {
            primaryText = "Unable to find notes for your meeting, try add";
            dbResponseModel.setPrimaryText(primaryText);
        }
        return dbResponseModel;
    }
}
