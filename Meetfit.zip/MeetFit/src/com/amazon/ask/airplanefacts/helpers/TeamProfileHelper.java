package com.amazon.ask.airplanefacts.helpers;

import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Employee;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.airplanefacts.util.HibernateUtil;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TeamProfileHelper extends ParentDbHelper {

    public static String TEAM_PROFILE_TABLE = "Team_Profile";
    public static String COLOUMN_TEAM_NAME = "teamName";
    public static String COLOUMN_TEAM_ID = "id";

    public DBResponseModel getTeamProfileData(String coloumn, String str) {
        ArrayList<TeamProfile> teamProfiles = new ArrayList<>();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            SQLQuery query = session.createSQLQuery("select id, teamName , teamEmailId, timestamp from Team_Profile where " + coloumn + "=\'" + str+ "\'");
            List<Object[]> rows = query.list();

            for (Object[] row : rows) {
                TeamProfile emp = new TeamProfile();
                emp.setId(Integer.parseInt(row[0].toString()));
                emp.setTeamName(row[1].toString());
                emp.setTeamEmailId(row[2].toString());
                emp.setTimestamp(Timestamp.valueOf(row[3].toString()));
                teamProfiles.add(emp);
            }
            for (TeamProfile employee : teamProfiles) {
                log.info("TeamProfile : " + employee);
            }
        }

        if (teamProfiles.size() == 0)
            return getDbResponseModel(null);
        return getDbResponseModel(teamProfiles.get(0));
    }

    public DBResponseModel getTeamProfileData(String coloumn, Integer id) {
        return getTeamProfileData(coloumn, id.toString());
    }

    private DBResponseModel getDbResponseModel(Object pojo) {
        DBResponseModel dbResponseModel = new DBResponseModel();
        if (pojo != null) {
            dbResponseModel.setFound(true);
            dbResponseModel.setPojo(pojo);
        } else {
            primaryText = "Unable to find your team, try create team";
            dbResponseModel.setPrimaryText(primaryText);
        }
        return dbResponseModel;
    }
}
