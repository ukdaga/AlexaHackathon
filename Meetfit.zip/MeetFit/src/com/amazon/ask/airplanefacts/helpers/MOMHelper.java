package com.amazon.ask.airplanefacts.helpers;

import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.Notes;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.airplanefacts.util.EmailUtil;

import java.util.ArrayList;
import java.util.List;

public class MOMHelper {

    NotesHelper notesHelper = new NotesHelper();

    private String aggregateNotesToEmailBody(List<Notes> notesList) {
        StringBuilder sb = new StringBuilder();
        for (Notes notes : notesList) {
            sb.append(notes.getNoteType() + " on " + notes.getContent() + " for " + notes.getPersonName());
            sb.append("<break time=\"1s\"/>");
        }
        return sb.toString();
    }

    private List<Notes> getNotesForMeetingId(Meeting meeting) {
        DBResponseModel dbResponseModel = notesHelper.getNotesForID(NotesHelper.COLOUMN_MEETING_ID, meeting.getId());
        if (dbResponseModel.getFound()) {
            return (List<Notes>) dbResponseModel.getPojo();
        } else {
            return new ArrayList<>();
        }
    }

    public String createMOM(TeamProfile teamProfile, Meeting meeting) {
        List<Notes> notesList = getNotesForMeetingId(meeting);

        String subject = "MOM for Meeting : " + meeting.getType() + " for team : " + teamProfile.getTeamName();
        String bodyText = aggregateNotesToEmailBody(notesList);
//        EmailUtil.sendEmail(teamProfile.getTeamEmailId(), subject, bodyText);
        return bodyText;
    }
}
