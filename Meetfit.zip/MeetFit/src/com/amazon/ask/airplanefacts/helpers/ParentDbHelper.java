package com.amazon.ask.airplanefacts.helpers;

import com.amazon.ask.airplanefacts.handlers.CreateTeamIntentHandler;
import com.amazon.ask.airplanefacts.model.Employee;
import com.amazon.ask.airplanefacts.util.HibernateUtil;
import lombok.Data;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

@Data
public class ParentDbHelper {
    String primaryText;
    static final Logger log = LogManager.getLogger(ParentDbHelper.class);

    public Object getDbData(String tableName, String coloumnName, String str) {

        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            SQLQuery query = session.createSQLQuery("select id, name from Employee");
            List<Object[]> rows = query.list();
            ArrayList<Employee> employees = new ArrayList<>();
            for (Object[] row : rows) {
                Employee emp = new Employee();
                emp.setId(Integer.parseInt(row[0].toString()));
                emp.setName(row[1].toString());
                employees.add(emp);
            }
            for (Employee employee : employees) {
                log.info("Employee : " + employee);
            }
        }

        //TODO Create request & return response;
        return null;
    }

    public Object getDbData(String tableName, String coloumnName, Integer id) {
        //TODO Create request & return response;
        return null;
    }

    public void saveInDB(Object obj) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.saveOrUpdate(obj);
            session.getTransaction().commit();
        }
    }

}
