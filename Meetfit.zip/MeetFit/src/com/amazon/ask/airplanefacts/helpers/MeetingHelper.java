package com.amazon.ask.airplanefacts.helpers;

import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.airplanefacts.util.HibernateUtil;
import com.amazon.ask.model.Response;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MeetingHelper extends ParentDbHelper {

    public static String MEETING_TABLE = "MeetingTable";
    public static String COLOUMN_DEVICE_ID = "deviceId";
    public static String COLOUMN_MEETING_TYPE = "MeetingType";
    public static String COLOUMN_MEETING_STATUS = "MeetingStatus";

    public DBResponseModel getMeetingData(String coloumn, String str) {
        ArrayList<Meeting> meetings = new ArrayList<>();
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            SQLQuery query = session.createSQLQuery("select id, teamId , type, timestamp,status,deviceId from Meeting where " + coloumn + "=\'" + str + "\' and status = \'1\'");
            List<Object[]> rows = query.list();

            for (Object[] row : rows) {
                Meeting emp = new Meeting();
                emp.setId(Integer.parseInt(row[0].toString()));
                emp.setTeamId(Integer.valueOf(row[1].toString()));
                emp.setType(row[2].toString());
                emp.setTimestamp(Timestamp.valueOf(row[3].toString()));
                emp.setStatus(getBool(row[4].toString()));
                emp.setDeviceId(row[5].toString());
                meetings.add(emp);
            }
            for (Meeting employee : meetings) {
                log.info("Meeting : " + employee);
            }
        }

        if (meetings.size() == 0)
            return getDbResponseModel(null);
        return getDbResponseModel(meetings.get(0));
    }

    private Boolean getBool(String toString) {
        if ("1" .equalsIgnoreCase(toString))
            return true;
        return false;
    }

    public DBResponseModel getMeetingData(String coloumn, Integer id) {
        return getMeetingData(coloumn, id.toString());
    }

    private DBResponseModel getDbResponseModel(Object pojo) {
        DBResponseModel dbResponseModel = new DBResponseModel();
        if (pojo != null) {
            dbResponseModel.setFound(true);
            dbResponseModel.setPojo(pojo);
        } else {
            primaryText = "Unable to find active meeting for your team, try start meeting";
            dbResponseModel.setPrimaryText(primaryText);
        }
        return dbResponseModel;
    }
}
