package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.model.Employee;
import com.amazon.ask.airplanefacts.model.Request;
import com.amazon.ask.airplanefacts.util.HibernateUtil;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

/**
 * @author arungupta
 */
public class EmployeeHandler implements RequestHandler<Request, String> {

    static final Logger log = LogManager.getLogger(EmployeeHandler.class);

    @Override
    public String handleRequest(Request request, Context context) {
        return pushToDb();
    }

    public static String pushToDb() {
        Request request;
        log.info("Request to query Employee table");
        request = new Request();
        request.setName("Devansh");
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            Employee employee = new Employee();
            employee.setId(request.id);
            employee.setName(request.name);
            session.save(employee);
            session.getTransaction().commit();
        }

        return String.format("Added %s %s.", request.id, request.name);
    }

    public static void getAllObj() {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            SQLQuery query = session.createSQLQuery("select id, name from Employee");
            List<Object[]> rows = query.list();
            ArrayList<Employee> employees = new ArrayList<>();
            for (Object[] row : rows) {
                Employee emp = new Employee();
                emp.setId(Integer.parseInt(row[0].toString()));
                emp.setName(row[1].toString());
                employees.add(emp);
            }
            for (Employee employee : employees) {
                log.info("Employee : " + employee);
            }
        }
    }

    public static void getIdObj(Integer i) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
        try (Session session = sessionFactory.openSession()) {
            Transaction tx = session.beginTransaction();
            SQLQuery query = session.createSQLQuery("select id, name from Employee where id = " + i);
            List<Object[]> rows = query.list();
            ArrayList<Employee> employees = new ArrayList<>();
            for (Object[] row : rows) {
                Employee emp = new Employee();
                emp.setId(Integer.parseInt(row[0].toString()));
                emp.setName(row[1].toString());
                employees.add(emp);
            }
            for (Employee employee : employees) {
                log.info("Employee : " + employee);
            }
        }
    }
}
