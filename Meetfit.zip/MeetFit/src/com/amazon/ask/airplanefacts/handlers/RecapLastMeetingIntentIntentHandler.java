package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.helpers.MOMHelper;
import com.amazon.ask.airplanefacts.helpers.MeetingHelper;
import com.amazon.ask.airplanefacts.helpers.ResponseHelper;
import com.amazon.ask.airplanefacts.helpers.TeamProfileHelper;
import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class RecapLastMeetingIntentIntentHandler implements RequestHandler {

    static final Logger log = LogManager.getLogger(FactIntentHandler.class);
    public final String RECAP_LAST_MEETING_INTENT = "RecapLastMeetingIntent";
    private MeetingHelper meetingHelper = new MeetingHelper();
    private TeamProfileHelper teamHelper = new TeamProfileHelper();
    private MOMHelper momHelper = new MOMHelper();

    @Override
    public boolean canHandle(HandlerInput handlerInput) {
        return handlerInput.matches(intentName(RECAP_LAST_MEETING_INTENT));
    }

    @Override
    public Optional<Response> handle(HandlerInput handlerInput) {

        IntentRequest intentName = (IntentRequest) handlerInput.getRequestEnvelope().getRequest();
        Map<String, Slot> slotMap = intentName.getIntent().getSlots();
        String primaryText;
        TeamProfile teamProfile = new TeamProfile();
        Meeting currentMeeting;

        String deviceId = handlerInput.getRequestEnvelope().getContext().getSystem().getDevice().getDeviceId();

        DBResponseModel dbResponseModel = meetingHelper.getMeetingData(MeetingHelper.COLOUMN_DEVICE_ID, deviceId);
        if (dbResponseModel.getFound()) {
            currentMeeting = (Meeting) dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, dbResponseModel.getPrimaryText());
        }

        //TODO Fetch Old meeting

        DBResponseModel team_dbResponseModel = teamHelper.getTeamProfileData(TeamProfileHelper.COLOUMN_TEAM_ID, currentMeeting.getTeamId());
        if (team_dbResponseModel.getFound()) {
            teamProfile = (TeamProfile) team_dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, team_dbResponseModel.getPrimaryText());
        }

        if (currentMeeting.getStatus()) {
            momHelper.createMOM(teamProfile, currentMeeting);
            primaryText = "MOM will be sent, thank for using Alexa today!";
        } else {
            primaryText = "You did not have any active meeting";
            //TODO Return from here
        }

        String speechText = "<speak>" + primaryText + "</speak>";

        return ResponseHelper.getResponseAbruptly(handlerInput, primaryText);
    }

}
