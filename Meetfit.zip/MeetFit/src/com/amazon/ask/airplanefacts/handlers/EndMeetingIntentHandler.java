package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.helpers.MOMHelper;
import com.amazon.ask.airplanefacts.helpers.MeetingHelper;
import com.amazon.ask.airplanefacts.helpers.ResponseHelper;
import com.amazon.ask.airplanefacts.helpers.TeamProfileHelper;
import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.Notes;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.airplanefacts.util.EmailUtil;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class EndMeetingIntentHandler implements RequestHandler {

    static final Logger log = LogManager.getLogger(FactIntentHandler.class);
    public final String END_MEETING_INTENT = "EndMeetingIntent";
    public final String TITLE = "MeetFit";
    private MeetingHelper meetingHelper = new MeetingHelper();
    private TeamProfileHelper teamHelper = new TeamProfileHelper();
    private MOMHelper momHelper = new MOMHelper();

    @Override
    public boolean canHandle(HandlerInput handlerInput) {
        return handlerInput.matches(intentName(END_MEETING_INTENT));
    }

    @Override
    public Optional<Response> handle(HandlerInput handlerInput) {

        IntentRequest intentName = (IntentRequest) handlerInput.getRequestEnvelope().getRequest();
        Map<String, Slot> slotMap = intentName.getIntent().getSlots();
        String primaryText;
        TeamProfile teamProfile = new TeamProfile();
        Meeting meeting;

        String deviceId = handlerInput.getRequestEnvelope().getContext().getSystem().getDevice().getDeviceId();

        DBResponseModel dbResponseModel = meetingHelper.getMeetingData(MeetingHelper.COLOUMN_DEVICE_ID, deviceId);
        if (dbResponseModel.getFound()) {
            meeting = (Meeting) dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, dbResponseModel.getPrimaryText());
        }

        DBResponseModel team_dbResponseModel = teamHelper.getTeamProfileData(TeamProfileHelper.COLOUMN_TEAM_ID, meeting.getTeamId());
        if (team_dbResponseModel.getFound()) {
            teamProfile = (TeamProfile) team_dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, team_dbResponseModel.getPrimaryText());
        }

        if (meeting.getStatus()) {
            primaryText = "Minutes of meeting is <break time=\"1s\"/>" + momHelper.createMOM(teamProfile, meeting) + "<break time=\"1s\"/> , this will be sent as email";

            //Meeting was active, so turn it off
            meeting.setStatus(false);
            meetingHelper.saveInDB(meeting);
        } else {
            primaryText = "You did not have any active meeting";
            //TODO Return from here
        }

        String speechText = "<speak>" + primaryText + "</speak>";

        return ResponseHelper.getResponseAbruptly(handlerInput, primaryText);
    }
}
