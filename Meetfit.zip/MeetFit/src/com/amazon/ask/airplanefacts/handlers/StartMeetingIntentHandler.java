package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.helpers.MeetingHelper;
import com.amazon.ask.airplanefacts.helpers.ResponseHelper;
import com.amazon.ask.airplanefacts.helpers.TeamProfileHelper;
import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Timestamp;
import java.util.Map;
import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class StartMeetingIntentHandler implements RequestHandler {

    static final Logger log = LogManager.getLogger(FactIntentHandler.class);
    public final String START_MEETING_INTENT = "StartMeetingIntent";
    public final String TITLE = "MeetFit";
    public final String SLOT_TYPE = "Type";
    private TeamProfileHelper teamHelper = new TeamProfileHelper();
    private MeetingHelper meetingHelper = new MeetingHelper();

    @Override
    public boolean canHandle(HandlerInput handlerInput) {
        return handlerInput.matches(intentName(START_MEETING_INTENT));
    }

    @Override
    public Optional<Response> handle(HandlerInput handlerInput) {

        IntentRequest intentName = (IntentRequest) handlerInput.getRequestEnvelope().getRequest();
        Map<String, Slot> slotMap = intentName.getIntent().getSlots();
        String primaryText;
        TeamProfile teamProfile = new TeamProfile();
        Meeting meeting;

        if (slotMap.containsKey(CreateTeamIntentHandler.SLOT_TEAM_NAME)) {
            DBResponseModel team_dbResponseModel = teamHelper.getTeamProfileData(TeamProfileHelper.COLOUMN_TEAM_NAME, slotMap.get(CreateTeamIntentHandler.SLOT_TEAM_NAME).getValue());
            if (team_dbResponseModel.getFound()) {
                teamProfile = (TeamProfile) team_dbResponseModel.getPojo();
            } else {
                return ResponseHelper.getResponseAbruptly(handlerInput, "Team name is mandatory, cannot proceed");
            }
        } else {
            //Not needed, Alexa already blocks request without these attributes
        }

        if (slotMap.containsKey(SLOT_TYPE)) {
            String meetingType = slotMap.get(SLOT_TYPE).getValue();

            //TODO check if meeting type already exist for that team?
            if (false) {
                //Mark meeting status = true
                //Exit from here
            }

            //Create Meeting
            meeting = new Meeting();
            meeting.setTeamId(teamProfile.getId());
            meeting.setType(meetingType);
            meeting.setTimestamp(new Timestamp(System.currentTimeMillis()));
            meeting.setStatus(true);
            String deviceId = handlerInput.getRequestEnvelope().getContext().getSystem().getDevice().getDeviceId();
            meeting.setDeviceId(deviceId);

            primaryText = "Sure, Starting meeting " + meeting.getType() + " for team ";
            meetingHelper.saveInDB(meeting);

        } else {
            //PS Not needed, Alexa already blocks request without these attributes
            primaryText = "You made an error in your request!";
        }

        String speechText = "<speak>" + primaryText + "</speak>";

        return handlerInput.getResponseBuilder()
                .withSpeech(speechText)
                .withSimpleCard(TITLE, primaryText)
                .withReprompt(speechText)
                .build();
    }
}
