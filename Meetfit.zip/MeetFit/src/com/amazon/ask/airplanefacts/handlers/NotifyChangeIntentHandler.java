package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.helpers.MeetingHelper;
import com.amazon.ask.airplanefacts.helpers.ResponseHelper;
import com.amazon.ask.airplanefacts.helpers.TeamProfileHelper;
import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.airplanefacts.util.EmailUtil;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.Context;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class NotifyChangeIntentHandler implements RequestHandler {

    static final Logger log = LogManager.getLogger(FactIntentHandler.class);
    public final String NOTIFY_CHANGE_INTENT = "NotifyVenueAndTimeChangeIntent";
    public final String SLOT_VENUE = "Venue";
    public final String SLOT_TIME = "Time";
    private MeetingHelper meetingHelper = new MeetingHelper();
    private TeamProfileHelper teamHelper = new TeamProfileHelper();

    @Override
    public boolean canHandle(HandlerInput handlerInput) {
        return handlerInput.matches(intentName(NOTIFY_CHANGE_INTENT));
    }

    @Override
    public Optional<Response> handle(HandlerInput handlerInput) {

        IntentRequest intentName = (IntentRequest) handlerInput.getRequestEnvelope().getRequest();
        Map<String, Slot> slotMap = intentName.getIntent().getSlots();
        String primaryText;
        TeamProfile teamProfile;
        Meeting meeting = new Meeting();

        String deviceId = handlerInput.getRequestEnvelope().getContext().getSystem().getDevice().getDeviceId();

        DBResponseModel dbResponseModel = meetingHelper.getMeetingData(MeetingHelper.COLOUMN_DEVICE_ID, deviceId);
        if (dbResponseModel.getFound()) {
            meeting = (Meeting) dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, dbResponseModel.getPrimaryText());
        }

        DBResponseModel team_dbResponseModel = teamHelper.getTeamProfileData(TeamProfileHelper.COLOUMN_TEAM_ID, meeting.getTeamId());
        if (team_dbResponseModel.getFound()) {
            teamProfile = (TeamProfile) team_dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, team_dbResponseModel.getPrimaryText());
        }

        //TODO Add excpetion handling in no team

        if (slotMap.containsKey(SLOT_VENUE)) {
            String subject = "Venue change update for " + teamProfile.getTeamName() + " meeting :" + meeting.getType();
            String bodyText = "Hi Team, \n Update to Venue for the meeting , new Venue is : " + slotMap.get(SLOT_VENUE);
//            EmailUtil.sendEmail(teamProfile.getTeamEmailId(), subject, bodyText);
            //TODO Return from here
        } else {
            //Do nothing
        }

        if (slotMap.containsKey(SLOT_TIME)) {
            String subject = "Meeting time change update for " + teamProfile.getTeamName() + " meeting :" + meeting.getType();
            String bodyText = "Hi Team, \n Update to Meeting time , re-scheduled time is : " + slotMap.get(SLOT_TIME);
//            EmailUtil.sendEmail(teamProfile.getTeamEmailId(), subject, bodyText);
            //TODO Return from here
        } else {
            //Do nothing
        }

        primaryText = "Meeting update sent to Team email";

        return ResponseHelper.getResponseAbruptly(handlerInput,primaryText);
    }
}
