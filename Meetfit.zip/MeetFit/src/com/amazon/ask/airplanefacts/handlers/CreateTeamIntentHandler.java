package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.helpers.TeamProfileHelper;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Timestamp;
import java.util.Map;
import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class CreateTeamIntentHandler implements RequestHandler {

    static final Logger log = LogManager.getLogger(CreateTeamIntentHandler.class);
    public static final String CREATE_TEAM_INTENT = "CreateTeamIntent";
    public static final String TITLE = "MeetFit";
    public static final String SLOT_TEAM_NAME = "TeamName";
    public static final String SLOT_TEAM_EMAIL_PREFIX = "EmailPrefix";
    public static final String SLOT_TEAM_EMAIL_HOST = "EmailHost";
    TeamProfileHelper teamProfileHelper = new TeamProfileHelper();

    @Override
    public boolean canHandle(HandlerInput handlerInput) {
        return handlerInput.matches(intentName(CREATE_TEAM_INTENT));
    }

    @Override
    public Optional<Response> handle(HandlerInput handlerInput) {
        IntentRequest intentName = (IntentRequest) handlerInput.getRequestEnvelope().getRequest();
        Map<String, Slot> slotMap = intentName.getIntent().getSlots();
        String primaryText;
        TeamProfile teamProfile = new TeamProfile();
        if (slotMap.containsKey(SLOT_TEAM_NAME)) {

            //TODO Check if Team Name already exist, then ignore
            //Save Team name
            teamProfile.setTeamName(slotMap.get(SLOT_TEAM_NAME).getValue());
            teamProfile.setTeamEmailId(assembleEmailId(slotMap));
            teamProfile.setTimestamp(new Timestamp(System.currentTimeMillis()));

            primaryText = "Sure, Team " + teamProfile.getTeamName() + " with email " + teamProfile.getTeamEmailId() + " will be created ";
            teamProfileHelper.saveInDB(teamProfile);
        } else {
            //PS Not needed, Alexa already blocks request without these attributes
            primaryText = "You made an error in your request!";
        }

        String speechText = "<speak>" + primaryText + "</speak>";

        return handlerInput.getResponseBuilder()
                .withSpeech(speechText)
                .withSimpleCard(TITLE, primaryText)
                .withReprompt(speechText)
                .build();
    }

    private String assembleEmailId(Map<String, Slot> slotMap) {
        String emailPrefix = slotMap.get(SLOT_TEAM_EMAIL_PREFIX).getValue();
        String emailHost = slotMap.get(SLOT_TEAM_EMAIL_HOST).getValue();
        String email = emailPrefix + "@" + emailHost + ".com";
        return email;
    }
}
