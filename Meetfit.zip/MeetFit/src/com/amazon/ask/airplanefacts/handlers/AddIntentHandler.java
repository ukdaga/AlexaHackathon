package com.amazon.ask.airplanefacts.handlers;

import com.amazon.ask.airplanefacts.helpers.MeetingHelper;
import com.amazon.ask.airplanefacts.helpers.NotesHelper;
import com.amazon.ask.airplanefacts.helpers.ResponseHelper;
import com.amazon.ask.airplanefacts.model.DBResponseModel;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.Notes;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import com.amazon.ask.airplanefacts.util.EmailUtil;
import com.amazon.ask.dispatcher.request.handler.HandlerInput;
import com.amazon.ask.dispatcher.request.handler.RequestHandler;
import com.amazon.ask.model.IntentRequest;
import com.amazon.ask.model.Response;
import com.amazon.ask.model.Slot;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.sql.Timestamp;
import java.util.Map;
import java.util.Optional;

import static com.amazon.ask.request.Predicates.intentName;

public class AddIntentHandler implements RequestHandler {

    static final Logger log = LogManager.getLogger(FactIntentHandler.class);
    public final String ADD_NOTE_INTENT = "AddIntent";
    public final String SLOT_NOTE_NAME = "NoteName";
    public final String SLOT_PERSON_NAME = "PersonName";
    public final String SLOT_SUBJECT_NAME = "SubjectName";
    public final String SLOT_DEADLINE = "Deadline";
    private MeetingHelper meetingHelper = new MeetingHelper();
    private NotesHelper notesHelper = new NotesHelper();

    @Override
    public boolean canHandle(HandlerInput handlerInput) {
        return handlerInput.matches(intentName(ADD_NOTE_INTENT));
    }

    @Override
    public Optional<Response> handle(HandlerInput handlerInput) {

        IntentRequest intentName = (IntentRequest) handlerInput.getRequestEnvelope().getRequest();
        Map<String, Slot> slotMap = intentName.getIntent().getSlots();
        String primaryText;
        Meeting meeting;

        String deviceId = handlerInput.getRequestEnvelope().getContext().getSystem().getDevice().getDeviceId();

        DBResponseModel dbResponseModel = meetingHelper.getMeetingData(MeetingHelper.COLOUMN_DEVICE_ID, deviceId);
        if (dbResponseModel.getFound()) {
            meeting = (Meeting) dbResponseModel.getPojo();
        } else {
            return ResponseHelper.getResponseAbruptly(handlerInput, dbResponseModel.getPrimaryText());
        }

        //TODO Add excpetion handling if no meeting found for team

        Notes notes = new Notes();
        notes.setMeetingId(meeting.getId());
        if (slotMap.containsKey(SLOT_NOTE_NAME)) {
            notes.setNoteType(slotMap.get(SLOT_NOTE_NAME).getValue());
        } else {
            primaryText = "NoteName is mandatory";
        }

        if (slotMap.containsKey(SLOT_SUBJECT_NAME)) {
            notes.setContent((slotMap.get(SLOT_SUBJECT_NAME).getValue()));
        } else {
            primaryText = "SubjectName is mandatory";
        }

        if (slotMap.containsKey(SLOT_PERSON_NAME)) {
            notes.setPersonName((slotMap.get(SLOT_PERSON_NAME).getValue()));
        } else {
            //Do nothing
        }

        if (slotMap.containsKey(SLOT_DEADLINE)) {
            notes.setPersonName((slotMap.get(SLOT_DEADLINE).getValue()));
        } else {
            //Do nothing
        }

        notes.setTimestamp(new Timestamp(System.currentTimeMillis()));
        notesHelper.saveInDB(notes);

        return ResponseHelper.getResponseAbruptly(handlerInput, "Noted!");
    }
}
