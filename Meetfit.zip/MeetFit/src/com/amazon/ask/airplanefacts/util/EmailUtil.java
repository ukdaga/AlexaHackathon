package com.amazon.ask.airplanefacts.util;

import com.amazon.ask.airplanefacts.handlers.FactIntentHandler;
import com.amazonaws.internal.SdkInternalList;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailService;
import com.amazonaws.services.simpleemail.AmazonSimpleEmailServiceClientBuilder;
import com.amazonaws.services.simpleemail.model.Body;
import com.amazonaws.services.simpleemail.model.Content;
import com.amazonaws.services.simpleemail.model.Destination;
import com.amazonaws.services.simpleemail.model.ListVerifiedEmailAddressesResult;
import com.amazonaws.services.simpleemail.model.Message;
import com.amazonaws.services.simpleemail.model.SendEmailRequest;
import com.amazonaws.services.simpleemail.model.SendEmailResult;
import com.amazonaws.services.simpleemail.model.VerifyEmailAddressRequest;
import com.amazonaws.services.simpleemail.model.VerifyEmailAddressResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;

public class EmailUtil {

    static final Logger log = LogManager.getLogger(FactIntentHandler.class);

    private static AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard().build();

    public static void verifyEmails(String emailAddress) {
        log.info("Email to verify  : " + emailAddress);

        ListVerifiedEmailAddressesResult verifiedEmail = client.listVerifiedEmailAddresses();
        if (verifiedEmail.getVerifiedEmailAddresses().contains(emailAddress)) {
            log.info(emailAddress + " Email already verified!");
            return;
        }

        VerifyEmailAddressRequest verifyEmailAddressRequest = new VerifyEmailAddressRequest();
        verifyEmailAddressRequest.setEmailAddress(emailAddress);

        VerifyEmailAddressResult verify = client.verifyEmailAddress(verifyEmailAddressRequest);
        log.info("Verify Email response : " + verify.getSdkResponseMetadata());
    }

    public static void sendEmail(String toEmail, String subject, String bodyText) {
        String fromEmail = "drrusia@amazon.com";
        verifyEmails(fromEmail);
        for (String email : toEmail.split(",")) {
            verifyEmails(email);
        }

        log.info("Email message being created");

        AmazonSimpleEmailService client = AmazonSimpleEmailServiceClientBuilder.standard().build();
        SendEmailRequest request = new SendEmailRequest()
                .withSource(fromEmail)
                .withDestination(new Destination().withToAddresses(toEmail.split(",")))
                .withMessage(new Message()
                        .withSubject(new Content().withData(subject).withCharset("UTF-8"))
                        .withBody(new Body().withText(new Content().withData(bodyText).withCharset("UTF-8"))));

        //TODO Handle com.amazonaws.services.simpleemail.model.MessageRejectedException cleanly!
        SendEmailResult response = client.sendEmail(request);
        log.info("Email is away!");
    }
}
