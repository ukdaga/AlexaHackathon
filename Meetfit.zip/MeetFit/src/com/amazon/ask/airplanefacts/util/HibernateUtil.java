package com.amazon.ask.airplanefacts.util;
/**
 * @author argu
 */

import com.amazon.ask.airplanefacts.handlers.FactIntentHandler;
import com.amazon.ask.airplanefacts.model.Employee;
import com.amazon.ask.airplanefacts.model.Meeting;
import com.amazon.ask.airplanefacts.model.Notes;
import com.amazon.ask.airplanefacts.model.TeamProfile;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class HibernateUtil {

    private static SessionFactory sessionFactory;

    static final Logger log = LogManager.getLogger(HibernateUtil.class);

    public static SessionFactory getSessionFactory() {
        log.info("Fetching session factory");
        if (null != sessionFactory)
            return sessionFactory;

        Configuration configuration = new Configuration();

        String jdbcUrl = "jdbc:mysql://"
                + "hackathondbinstance.cwcvva7iruau.us-east-1.rds.amazonaws.com"
                + "/"
                + "alexahackathondatabase";

        configuration.setProperty("hibernate.connection.url", jdbcUrl);
        configuration.setProperty("hibernate.connection.username", "meetfit_user");
        configuration.setProperty("hibernate.connection.password", "amazonalexa234");

        configuration.configure();
        configuration.addAnnotatedClass(Employee.class);
        configuration.addAnnotatedClass(TeamProfile.class);
        configuration.addAnnotatedClass(Meeting.class);
        configuration.addAnnotatedClass(Notes.class);
        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        log.info("Db Session to be created");
        try {
            sessionFactory = configuration.buildSessionFactory(serviceRegistry);
        } catch (HibernateException e) {
            System.err.println("Initial SessionFactory creation failed." + e);
            throw new ExceptionInInitializerError(e);
        }
        log.info("Db Session to be created sucessfully");
        return sessionFactory;
    }
}
