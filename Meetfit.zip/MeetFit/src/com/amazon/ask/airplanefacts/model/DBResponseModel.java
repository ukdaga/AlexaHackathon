package com.amazon.ask.airplanefacts.model;

import lombok.Data;

@Data
public class DBResponseModel {
    Object pojo;
    String primaryText;
    Boolean found = false;
}
