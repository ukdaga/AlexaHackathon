package com.amazon.ask.airplanefacts.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "Team_Profile")
public class TeamProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer id;
    String teamName;
    String teamEmailId;
    Timestamp timestamp;
}
